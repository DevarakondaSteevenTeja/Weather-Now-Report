import React, { useState } from "react";

const getWeatherDisplay = (code) => {
  const iconMap = {
    0: { icon: "☀️", description: "Clear Sky" },
    1: { icon: "🌤️", description: "Mainly Clear" },
    2: { icon: "⛅", description: "Partly Cloudy" },
    3: { icon: "☁️", description: "Overcast" },
    45: { icon: "🌫️", description: "Fog" },
    48: { icon: "🌫️", description: "Rime Fog" },
    51: { icon: "🌧️", description: "Light Drizzle" },
    61: { icon: "☔", description: "Slight Rain" },
    63: { icon: "🌧️", description: "Moderate Rain" },
    65: { icon: "🌧️", description: "Heavy Rain" },
    71: { icon: "❄️", description: "Slight Snow Fall" },
    73: { icon: "🌨️", description: "Moderate Snow Fall" },
    80: { icon: "🌦️", description: "Slight Showers" },
    82: { icon: "⛈️", description: "Violent Showers" },
    95: { icon: "🌩️", description: "Thunderstorm" },
  };

  return iconMap[code] || { icon: "❓", description: "Unknown" };
};

const getWindDirection = (degree) => {
  if (degree > 337.5 || degree <= 22.5) return "N";
  if (degree > 22.5 && degree <= 67.5) return "NE";
  if (degree > 67.5 && degree <= 112.5) return "E";
  if (degree > 112.5 && degree <= 157.5) return "SE";
  if (degree > 157.5 && degree <= 202.5) return "S";
  if (degree > 202.5 && degree <= 247.5) return "SW";
  if (degree > 247.5 && degree <= 292.5) return "W";
  if (degree > 292.5 && degree <= 337.5) return "NW";
  return "";
};

const SearchBar = ({ onSearch }) => {
  const [city, setCity] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    if (city.trim()) {
      onSearch(city.trim());
      setCity("");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="search-form">
      <input
        type="text"
        placeholder="Enter City Name (e.g., London)"
        value={city}
        onChange={(e) => setCity(e.target.value)}
        className="search-input"
      />
      <button type="submit" className="search-button">
        Search
      </button>
    </form>
  );
};

const DetailCard = ({ title, value, icon }) => (
  <div className="detail-card">
    <span className="detail-icon">{icon}</span>
    <p className="detail-title">{title}</p>
    <p className="detail-value">{value}</p>
  </div>
);

const WeatherDisplay = ({ data, locationName }) => {
  if (!data) return null;

  const current = data.current;
  const hourly = data.hourly;

  const currentCondition = getWeatherDisplay(current.weather_code);
  const currentTime = new Date(current.time);

  const nextHours = hourly.time
    .map((t, index) => ({
      time: new Date(t),
      temp: hourly.temperature_2m[index],
      code: hourly.weather_code[index],
    }))
    .filter((item) => item.time >= currentTime)
    .slice(0, 8);

  const formatHour = (date) =>
    date.getHours().toString().padStart(2, "0") + ":00";

  return (
    <div className="weather-card">
      <h2 className="location-name">{locationName}</h2>
      <p className="time-info">
        {currentTime.toLocaleDateString()} at {currentTime.toLocaleTimeString()}
      </p>

      <div className="current-main">
        <div className="current-details">
          <span className="weather-icon">{currentCondition.icon}</span>
          <div className="temp-container">
            <p className="temperature">
              {Math.round(current.temperature_2m)}°F
            </p>
            <p className="description">{currentCondition.description}</p>
          </div>
        </div>
        <div className="feels-like">
          <p>Feels Like: {Math.round(current.apparent_temperature)}°F</p>
        </div>
      </div>

      <h3 className="details-heading">Outdoor Details (QuickCheck)</h3>
      <div className="detail-grid">
        <DetailCard
          title="Wind Speed"
          value={`${current.wind_speed_10m} mph`}
          icon="💨"
        />
        <DetailCard
          title="Wind Dir."
          value={getWindDirection(current.wind_direction_10m)}
          icon="🧭"
        />
        <DetailCard
          title="Precipitation"
          value={`${current.precipitation} mm`}
          icon="💧"
        />
        <DetailCard
          title="Humidity"
          value={`${current.relative_humidity_2m}%`}
          icon="💦"
        />
      </div>

      <h3 className="details-heading">Next 8 Hours</h3>
      <div className="hourly-scroll">
        {nextHours.map((hour, index) => {
          const hourlyCondition = getWeatherDisplay(hour.code);
          return (
            <div key={index} className="hourly-card">
              <p className="hourly-time">{formatHour(hour.time)}</p>
              <span className="hourly-icon">{hourlyCondition.icon}</span>
              <p className="hourly-temp">{Math.round(hour.temp)}°F</p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

function App() {
  const [weatherData, setWeatherData] = useState(null);
  const [locationName, setLocationName] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchWeatherData = async (city) => {
    setIsLoading(true);
    setError(null);
    setWeatherData(null);

    const GEO_API = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(
      city
    )}&count=1`;

    try {
      const geoResponse = await fetch(GEO_API);
      if (!geoResponse.ok) throw new Error("Geocoding API failed.");
      const geoJson = await geoResponse.json();

      if (!geoJson.results || geoJson.results.length === 0) {
        throw new Error(`Location "${city}" not found.`);
      }

      const { latitude, longitude, name, country } = geoJson.results[0];
      const foundLocation = `${name}, ${country}`;
      setLocationName(foundLocation);

      const WEATHER_API = `https://api.open-meteo.com/v1/forecast?
        latitude=${latitude}&
        longitude=${longitude}&
        current=temperature_2m,apparent_temperature,precipitation,wind_speed_10m,wind_direction_10m,weather_code,relative_humidity_2m&
        hourly=temperature_2m,weather_code&
        temperature_unit=fahrenheit&
        wind_speed_unit=mph&
        precipitation_unit=mm&
        timezone=auto
      `.replace(/\s/g, "");

      const weatherResponse = await fetch(WEATHER_API);
      if (!weatherResponse.ok) throw new Error("Weather API failed.");
      const weatherJson = await weatherResponse.json();

      setWeatherData(weatherJson);
    } catch (err) {
      console.error("Error fetching weather:", err);
      setError(
        err.message || "Failed to fetch weather data. Please try again."
      );
      setLocationName("");
      setWeatherData(null);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container">
      <h1 className="header">
        Jamie's <span className="highlight">QuickCheck</span> Weather 🌤️
      </h1>
      <SearchBar onSearch={fetchWeatherData} />

      {isLoading && (
        <div className="loading-message">
          <div className="spinner"></div>
          Fetching weather...
        </div>
      )}

      {error && (
        <div className="error-message">
          <p className="bold">Error:</p>
          <p>{error}</p>
        </div>
      )}

      <WeatherDisplay data={weatherData} locationName={locationName} />

      <footer className="footer">Data powered by Open-Meteo</footer>
    </div>
  );
}

export default App;
